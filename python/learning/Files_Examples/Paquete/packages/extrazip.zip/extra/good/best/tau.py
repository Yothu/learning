

""" module: tau """

def funT():
	return "Tau"

if __name__ == "__main__":
	print("I prefer to be a module.")